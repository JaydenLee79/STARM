
class STARM(OverSampling):
    """
    References:

    """

    categories = [OverSampling.cat_extensive,
                  OverSampling.cat_sample_ordinary]

    def __init__(self,
                 proportion=1.0,
                 n_neighbors=5,
                 rejection_level=0.5,
                 n_jobs=1,
                 topology='star',
                 random_state=None):
        """
        Constructor of the sampling object

        Args:
            proportion (float): proportion of the difference of n_maj and n_min
                                to sample e.g. 1.0 means that after sampling
                                the number of minority samples will be equal to
                                the number of majority samples
            n_neighbors (int): number of neighbors in nearest neighbor
                                component
            rejection_level (float): the rejection level of generated samples,
                                        if the fraction of majority labels in
                                        the local environment is higher than
                                        this number, the generated point is
                                        rejected
            n_jobs (int): number of parallel jobs
            random_state (int/RandomState/None): initializer of random_state,
                                                    like in sklearn
        """
        super().__init__()
        self.check_greater_or_equal(proportion, "proportion", 0)
        self.check_greater_or_equal(n_neighbors, "n_neighbors", 1)
        self.check_in_range(rejection_level, "rejection_level", [0, 1])
        self.check_n_jobs(n_jobs, 'n_jobs')

        self.check_isin(topology, "topology", ['star', 'bus', 'mesh'])

        self.proportion = proportion
        self.n_neighbors = n_neighbors
        self.rejection_level = rejection_level
        self.n_jobs = n_jobs
        self.topology = topology

        self.set_random_state(random_state)

    @ classmethod
    def parameter_combinations(cls, raw=False):
        """
        Generates reasonable paramter combinations.

        Returns:
            list(dict): a list of meaningful paramter combinations
        """
        parameter_combinations = {'proportion': [0.1, 0.25, 0.5, 0.75,
                                                 1.0, 1.5, 2.0],
                                  'n_neighbors': [3, 5, 7],
                                  'rejection_level': [0.1, 0.3, 0.5, 0.7, 0.9],
                                  'topology': ['star', 'mesh']}
        return cls.generate_parameter_combinations(parameter_combinations, raw)

    def sample(self, X, y):
        """
        Does the sample generation according to the class paramters.

        Args:
            X (np.ndarray): training set
            y (np.array): target labels

        Returns:
            (np.ndarray, np.array): the extended training set and target labels
        """
        _logger.info(self.__class__.__name__ + ": " +
                     "Running sampling via %s" % self.descriptor())

        self.class_label_statistics(X, y)

        if not self.check_enough_min_samples_for_sampling():
            return X.copy(), y.copy()

        n_to_sample = self.det_n_to_sample(self.proportion,
                                           self.class_stats[self.maj_label],
                                           self.class_stats[self.min_label])

        if n_to_sample == 0:
            _logger.warning(self.__class__.__name__ +
                            ": " + "Sampling is not needed")
            return X.copy(), y.copy()

        X_min = X[y == self.min_label]

        # fitting nearest neighbors models to find neighbors of minority
        # samples in the total data and in the minority datasets
        n_neighbors = min([len(X_min), self.n_neighbors + 1])
        nn = NearestNeighbors(n_neighbors=n_neighbors, n_jobs=self.n_jobs)
        nn.fit(X)
        dist, ind = nn.kneighbors(X_min)

        n_neighbors = min([len(X_min), self.n_neighbors + 1])
        nn_min = NearestNeighbors(n_neighbors=n_neighbors, n_jobs=self.n_jobs)
        nn_min.fit(X_min)
        dist_min, ind_min = nn_min.kneighbors(X_min)

        # do the sampling, we impleneted a continouos tweaking of rejection
        # levels in order to fix situations when no unrejectable data can
        # be can be generated
        samples = []
        passed = 0
        trial = 0
        rejection_level = self.rejection_level

        if self.topology == 'star':
            # Implementation of the star topology
            X_mean = np.mean(X_min, axis=0)
            k = max([1, int(np.rint(n_to_sample/len(X_min)))])
            for x in X_min:
                diff = X_mean - x
                for i in range(1, k+1):
                    sample_point = x + float(i)/(k+1)*diff
                    dist_new, ind_new = nn.kneighbors(sample_point.reshape(1, -1))
                    maj_frac = np.sum(y[ind_new][0][:-1] ==
                                    self.maj_label)/self.n_neighbors
                    if maj_frac < rejection_level:
                        samples.append(sample_point)

        elif self.topology == 'mesh':
            # Implementation of the mesh topology
            if len(X_min)**2 > n_to_sample:
                while len(samples) < n_to_sample:
                    random_i = self.random_state.randint(len(X_min))
                    random_j = self.random_state.randint(len(X_min))
                    diff = X_min[random_i] - X_min[random_j]
                    sample_point = X_min[random_i] + 0.5*diff
                    dist_new, ind_new = nn.kneighbors(sample_point.reshape(1, -1))
                    maj_frac = np.sum(y[ind_new][0][:-1] ==
                                    self.maj_label)/self.n_neighbors
                    if maj_frac < rejection_level:
                        samples.append(sample_point)
            else:
                n_combs = (len(X_min)*(len(X_min)-1)/2)
                k = max([1, int(np.rint(n_to_sample/n_combs))])
                for i in range(len(X_min)):
                    for j in range(len(X_min)):
                        diff = X_min[i] - X_min[j]
                        for li in range(1, k+1):
                            sample_point = X_min[j] + float(li)/(k+1)*diff
                            dist_new, ind_new = nn.kneighbors(sample_point.reshape(1, -1))
                            maj_frac = np.sum(y[ind_new][0][:-1] ==
                                            self.maj_label)/self.n_neighbors
                            if maj_frac < rejection_level:
                                samples.append(sample_point)

        while len(samples) < n_to_sample:
            # checking if we managed to generate a single data in 1000 trials
            if passed == trial and passed > 1000:
                rejection_level = rejection_level + 0.1
                trial = 0
                passed = 0
            trial = trial + 1

            # generating random point
            idx = self.random_state.randint(len(X_min))
            random_neighbor_idx = self.random_state.choice(ind_min[idx][1:])
            X_a = X_min[idx]
            X_b = X_min[random_neighbor_idx]
            random_point = self.sample_between_points(X_a, X_b)

            # checking if the local environment is above the rejection level
            dist_new, ind_new = nn.kneighbors(random_point.reshape(1, -1))
            maj_frac = np.sum(y[ind_new][0][:-1] ==
                              self.maj_label)/self.n_neighbors
            if maj_frac < rejection_level:
                samples.append(random_point)
            else:
                passed = passed + 1

        return (np.vstack([X, samples]),
                np.hstack([y, np.repeat(self.min_label, len(samples))]))

    def get_params(self, deep=False):
        """
        Returns:
            dict: the parameters of the current sampling object
        """
        return {'proportion': self.proportion,
                'n_neighbors': self.n_neighbors,
                'rejection_level': self.rejection_level,
                'n_jobs': self.n_jobs,
                'topology': self.topology,
                'random_state': self._random_state_init}

